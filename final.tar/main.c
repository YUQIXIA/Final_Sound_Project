#include <stdio.h>
#include "ourheader.h"
int main(void)
{printf("Mian function?\n");
foo();
}
