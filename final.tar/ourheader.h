//function prototype
void foo(void);
