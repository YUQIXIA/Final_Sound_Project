#include <stdio.h>
void foo(void)
{
printf("prnt function\n");
return;
}
